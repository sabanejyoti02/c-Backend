﻿namespace EmployeeManagement.Models
{
    public class Employee
    {
        public required int Id { get; set; }
        public required string Name { get; set; }
        public required string Position { get; set; }
        public required decimal Salary { get; set; }
        public int? Age { get; set; }
        public string? Contact { get; set; }

        public string? Email {get; set;}
    }
}
